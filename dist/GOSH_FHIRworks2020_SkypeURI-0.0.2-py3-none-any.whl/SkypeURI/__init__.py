from .SkypeURI import SkypeURI

__all__ = ['SkypeURI']